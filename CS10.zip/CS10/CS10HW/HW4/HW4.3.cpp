#include <iostream>
#include <cmath>
using namespace std;
double stddev(double a[],int size);
int main()
{
    int size =0;
    int k = 0;
    double a[1000];
    cout << "Enter elements ending with a -1: "<<endl;
    while(k!=-1){
        cin >> a[size];
        cin >> k;
        size++;
      }
    cout << "Standard Deviation = " << stddev(a,size)<<endl;
    return 0;
}
double stddev(double a[],int size)
{
    float sum = 0.0, mean, standardDeviation = 0.0;
    int i;
    for(i = 0; i < size; ++i)
    {
        sum += a[i];
    }
    mean = sum/size;
    for(i = 0; i < size; ++i)
        standardDeviation += pow(a[i] - mean, 2);
    return sqrt(standardDeviation / size);
}
