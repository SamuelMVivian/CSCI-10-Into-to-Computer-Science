#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>
using namespace std;
//computes average sore on a quiz given an undefined quantity of inputs
//also adds maximum score cap
//also gives min and max score
//uses arrays
void scores(int a[], int size, int &numberUsed);
double average (const int a[], int numberUsed);
void output (const int a[], int numberUsed);
const int maxScore = 900;
double max1 = 0;
double min1=30;

int main(){
  int score[maxScore];
  int used,number;
  cout<<"Enter number of scores to be input: "<<endl;
  cin>> number;
  scores(score,number+1,used);
  output(score,used);
return 0;
}

void scores(int a[], int size, int &numberUsed){
  cout<<"Enter up to "<<size-1<<"scores between 0 and 30"<<endl;
  cout<<"Mark the end of the list with a '-1' "<<endl;
  int score, index=0;
  cin>>score;
  while ((score>=0)&&(index<size&&score<=30)){
    a[index]=score;
    if(score>30) {
      cout<<"Error: invalid score "<<score<<endl;
      exit(1);
  }
    if(score>max1) max1=score;
    if(score<min1&&score!=-1) min1=score;
    index++;
    cin>>score;
  }
  numberUsed=index;
}

double average(const int a[], int numberUsed){
  double total=0;
  for(int i =0;i<numberUsed;i++)
    total=total+a[i];
    return (total/numberUsed);
}

void output(const int a[], int numberUsed){
  double average1=average(a,numberUsed);
  cout<<"Average: "<<average1<<endl;
  cout<<"Minimum: "<<min1<<endl;
  cout<<"Maximum: "<<max1<<endl;
}
