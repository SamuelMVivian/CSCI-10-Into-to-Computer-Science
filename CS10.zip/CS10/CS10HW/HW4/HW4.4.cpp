//problem 4 pg 237
#include <iostream>
#include <iomanip>
using namespace std;
const int MAX = 50;
void getValues(int arr[], int &arraySize);
void sortArray(int arr[], int arraySize);
void swapValues(int &a, int &b);
void repetition(int arr[], int times[], int &arraySize);
void showResults(int arr[], int times[], int arraySize);

int main(){
    int arr[MAX];
    int times[MAX];
    int arraySize;
    getValues(arr, arraySize);
    sortArray(arr, arraySize);
    repetition(arr, times, arraySize);
    showResults(arr, times, arraySize);
    cout << endl;
    return 0;
}
void getValues(int arr[], int &arraySize){
    cout << "How many values do you want to enter?";
    cin >> arraySize;
    for(int i = 0; i < arraySize; i++){
        cout << "Enter a value: ";
        cin >> arr[i];
    }
    return;
}
void sortArray(int arr[], int arraySize){
    for(int i = 0; i<arraySize; i++){
        for(int j = i+1; j<arraySize; j++){
            if(arr[i] < arr[j]){
                swapValues(arr[i], arr[j]);
            }
        }
    }
    return;
}
void swapValues(int &a, int &b){
    int temp = a;
    a = b;
    b = temp;
    return;
}

void repetition(int arr[], int times[], int &arraySize){
    for(int i = 0; i<arraySize; i++){
      int count=1;
        for(int j = i+1; j<arraySize; j++){
            if(arr[i] == arr[j]){
              count++;
                for(int m = j; m<arraySize-1; m++){
                  arr[m] = arr[m+1];
                }
                arraySize--;
                j--;
            }
        }
        times[i]=count;
    }
}
void showResults(int arr[], int times[], int arraySize){
    cout << setw(10) << "Number" << setw(20) << "Count"<< endl << endl;
    for(int i = 0; i<arraySize; i++){
        cout << setw(10) << arr[i] << setw(20) << times[i] << endl;
    }
    return;
}
