#include <iostream>
using namespace std;

int reverseNumber(int n);

int main(){
cout<<reverseNumber(954)<<endl;
return 0;
}

int reverseNumber(int n){
int reverse=0, rem;
	while(n!=0){
		rem=n%10;
		reverse=reverse*10+rem;
		n=n/10;
	}
return reverse;
}
