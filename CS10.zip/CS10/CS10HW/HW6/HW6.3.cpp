#include <iostream>
#include <cstring>
#include <fstream>
using namespace std;

void sortTwoFiles (ifstream& in1, ifstream& in2, ofstream &out);

int main()
{
  ifstream inFile1;//declare variables
  ifstream inFile2;
  ofstream outFile;
  string inFileName1;
  string inFileName2;
  string outFileName;

  cout<< "Enter the first input file: ";//prompt user to enter file names
  cin>>inFileName1;
  cout<<"Enter the second input file: ";
  cin>>inFileName2;
  cout<<"Enter the output file: ";
  cin>>outFileName;

inFile1.open(inFileName1);//try to open files, if doest work send error message
if(inFile1.fail())
  {
    cout<<"first file did not open\n";
    system("pause");
    exit(1);
  }
inFile2.open(inFileName2);
if(inFile2.fail())
  {
    cout<< "second file did not open\n";
    system("pause");
    exit(1);
  }
outFile.open(outFileName);
if(outFile.fail())
  {
    cout<<"the third file did not open\n";
    system("pause");
    exit(1);
  }
  sortTwoFiles(inFile1, inFile2, outFile);
  inFile1.close();
  inFile2.close();
  outFile.close();
  system("pause");
  return 0;
}
void sortTwoFiles(ifstream& in1, ifstream& in2, ofstream& out)
{
  int integer1;
  int integer2;
  in1>>integer1;
  in2>>integer2;
  while(!in1.eof() && !in2.eof())
  {
    if(integer1<=integer2)
    {
      out<<integer1<<endl;
      in1>>integer1;
    }
    else
    {
      out<<integer2<<endl;
      in2>>integer2;
    }
  }//end of while loop
  if(integer1<=integer2)
  {
    while (!in2.eof())
    {
      out<<integer2<<endl;
      in2>>integer2;
    }
  }
  else
  {
    while(!in1.eof())
    {
      out<<integer1<<endl;
      in1>>integer1;
    }
  }
}
