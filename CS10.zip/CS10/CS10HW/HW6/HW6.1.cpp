#include <iostream>
#include <fstream>
using namespace std;

const int MAX_STUDENTS=6;
const double QUIZES_COUNT = .25;
const double MIDTERM_COUNTS= .25;
const double FINAL_COUNTS=.50;

struct StudentScoresAndGrade
{
  int studentID;
  double pointsInFirstQuiz;
  double pointsInSecondQuiz;
  double pointsInMidtermExam;
  double pointsInFinalExam;
  double averageScore;
  char studentGrade;
};
void getStudentDetails(StudentScoresAndGrade & studentDetails);
void calculateStudentGrade(StudentScoresAndGrade & studentDetails);
void displayStudentResult(const StudentScoresAndGrade studentDetails);

int main()
{
  StudentScoresAndGrade studentDetails[MAX_STUDENTS];
  for (int student=0; student<MAX_STUDENTS; student++)
  getStudentDetails(studentDetails[student]);
  for (int student=0; student<MAX_STUDENTS; student++)
  calculateStudentGrade(studentDetails[student]);
  for(int student=0; student<MAX_STUDENTS; student++)
  displayStudentResult(studentDetails[student]);

  system("pause");
  return 0;
}
 void getStudentDetails(StudentScoresAndGrade &studentDetails)
 {
   cout << "Enter the student ID: ";
   cin>> studentDetails.studentID;
   cout<<"Enter the number of points in quiz 1 (Max points=10)";
   cin>> studentDetails.pointsInFirstQuiz;
   cout<<"Enter the number of points in quiz 2 (Max points=10)";
   cin>> studentDetails.pointsInSecondQuiz;
   cout<<"Enter the number of points in midterm exam (Max points=100): ";
   cin>> studentDetails.pointsInMidtermExam;
   cout<<"Enter the number of points in final exam (Max points=100): ";
   cin>>studentDetails.pointsInFinalExam;
   cout<<endl;
 }

void calculateStudentGrade(StudentScoresAndGrade& studentDetails)
{
  double totalOfQuizes;
  double averageOfQuizes;
  double normalizedAverageOfQuizes;
  double quizesScore;
  double midtermExamScore;
  double finalExamScore;

  totalOfQuizes= studentDetails.pointsInFirstQuiz + studentDetails.pointsInSecondQuiz;
  averageOfQuizes= totalOfQuizes /2.0;
  normalizedAverageOfQuizes = averageOfQuizes *10;
  quizesScore = normalizedAverageOfQuizes * QUIZES_COUNT;
  midtermExamScore = studentDetails.pointsInMidtermExam * MIDTERM_COUNTS;
  finalExamScore = studentDetails.pointsInFinalExam * FINAL_COUNTS;
  studentDetails.averageScore = quizesScore + midtermExamScore + finalExamScore;

  if(studentDetails.averageScore>=90)
  studentDetails.studentGrade = 'A';
  else if (studentDetails.averageScore >= 80)
  studentDetails.studentGrade = 'B';
  else if (studentDetails.averageScore >=70)
  studentDetails.studentGrade = 'C';
  else if (studentDetails.averageScore >=60)
  studentDetails.studentGrade = 'D';
  else
  studentDetails.studentGrade = 'F';
}

void displayStudentResult(const StudentScoresAndGrade studentDetails)
{
  cout <<"\n The student ID: " << studentDetails.studentID << endl;
  cout << "The points on the first quiz: " <<studentDetails.pointsInFirstQuiz << endl;
  cout << "The points on the second quiz: " <<studentDetails.pointsInSecondQuiz <<endl;
  cout << "The points on the midterm exam: " <<studentDetails.pointsInMidtermExam <<endl;
  cout << "The points on the final exam: " <<studentDetails.pointsInFinalExam <<endl;
  cout << "The average points on all exams: " <<studentDetails.averageScore <<endl;
  cout << "The grade of the student: " << studentDetails.studentGrade << endl;
}
