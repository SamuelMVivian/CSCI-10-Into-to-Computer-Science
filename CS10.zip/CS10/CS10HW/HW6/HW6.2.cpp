#include <iostream>
#include <string>
using namespace std;

struct Fraction {
  int numerator;
  int denominator;
};

void printFraction (Fraction f);

Fraction Mult (Fraction f1, Fraction f2);

Fraction add(Fraction f1, Fraction f2);


int main ()
{
  struct Fraction f1;
  f1.numerator=3;
  f1.denominator=4;

  struct Fraction f2;
  f2.numerator=5;
  f2.denominator=6;

  struct Fraction multResult, addResult;

  cout<< "Fraction f1: ";
  printFraction(f1);
  cout<< "Fraction f2: ";
  printFraction(f2);
  cout<<endl;

  multResult=Mult(f1,f2);
  cout<<"Multiplication Result: ";
  printFraction(multResult);

  addResult=add(f1,f2);
  cout<<"Addition Result: ";
  printFraction(addResult);

  return 0;
}

void printFraction (Fraction f)
{
  cout << f.numerator<<"/"<<f.denominator<<endl;
}
Fraction Mult (Fraction f1, Fraction f2)
{
  struct Fraction result;
  result.numerator=f1.numerator*f2.numerator;
  result.denominator=f1.denominator*f2.denominator;
  return result;
}

Fraction add(Fraction f1, Fraction f2)
{
  struct Fraction result;

  result.numerator=(f1.numerator*f2.denominator)+(f2.numerator*f1.denominator);
  result.denominator=f1.denominator*f2.denominator;

  return result;
}
