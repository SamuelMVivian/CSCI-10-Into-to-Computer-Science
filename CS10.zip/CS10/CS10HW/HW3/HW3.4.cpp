//problem 13 page 184 of text book
#include <iostream>
using namespace std;

double convertToMPH(int paceInMin, int paceInSec);
double convertToMPH(double kph);


int main()
{
	int paceInMin;
	int paceInSec;
	double kph;

	cout << "Enter your pace - minutes: ";
	cin >> paceInMin;
	cout << "Enter your pace - seconds: ";
	cin >> paceInSec;
	cout << "Your speed in mph is " << convertToMPH(paceInMin, paceInSec) << endl;

	cout << "Enter your speed in kph: ";
	cin >> kph;
	cout << "Your speed in mph is " << convertToMPH(kph)<<endl;

	return 0;
}

double convertToMPH(int paceInMin, int paceInSec)
{
	return(60 / (paceInMin + paceInSec / 60.));
}
double convertToMPH(double kph)
{
	return (kph / 1.61);
}
