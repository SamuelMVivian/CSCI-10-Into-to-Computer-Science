#include <iostream>
#include <cmath>
#include <string>
using namespace std;
//problem 10 og 183 length and width conversions
void inputL(double &feet,double &inches, double &meters, double &cm);
void inputW(double &pound, double &ounces, double &kg, double &grams);
void calcFeetInches(double feet,double inches,double &meters,double &cm);
void calcMetersCm(double meters, double cm, double &feet, double &inches);
void calcPoundsOunces(double pounds, double ounces, double &kg, double &grams);
void calcKgGrams(double kg, double grams,double &pounds, double &ounces);

int main()
{
	 double feet, inches, meters, cm, pounds, ounces, kg, grams;
    int choose, loop;
  do
  {
      cout << "Select conversion\n"<<"1. Weight\n"<<"2. Length\n";
      cin>>choose;
			if (choose==1){
				inputW(pounds,ounces,kg,grams);
			}else if(choose==2){
				inputL(feet, inches, meters, cm);
			}
		}while (loop !='n'||loop!='N');
		return 0;
	}

	void inputW (double& pounds, double& ounces, double& kg, double& grams) {
	int choose;
	cout << "Type of conversion: \n" << "1. Lbs/oz to Kg/g\n" << "2. Kg/g to Lbs/oz\n";
	cin >> choose;
	if (choose == 1) {
		cout << "Enter pounds: ";
		cin >> pounds;
		cout << "ounces: ";
		cin >> ounces;
		calcPoundsOunces(pounds, ounces, kg, grams);
		cout << pounds << "Lbs " << ounces << " oz = "
			 << kg << "Kg and " << grams << " g\n";
	}
	else if (choose == 2){
		cout << "Enter Kg: ";
		cin >> kg;
		cout << "g: ";
		cin >> grams;
		calcKgGrams(kg, grams, pounds, ounces);
		cout << kg << "Kg and " << grams << "g = "
			 << pounds << " Lbs and " << ounces << " oz\n";
	}
	else {
		cout << "Error: improper selection.\n";
	}
}

void inputL(double& feet, double& inches, double& meters, double& cm) {
	int choose;
	cout << "Type of conversion?: \n" << "1. Ft/in to m/cm\n"
		 << "2. m/cm to ft/in\n";
	cin >> choose;
	if (choose == 1) {
		cout << "Enter feet: ";
		cin >> feet;
		cout << "Inches: ";
		cin >> inches;
		calcFeetInches(feet, inches, meters, cm);
		cout << feet << " ft and " << inches << "in = "
			 << meters << "m and " << cm << "cm\n";
	}
	else if (choose == 2) {
		cout << "Enter meters: ";
		cin >> meters;
		cout << "Centimeters: ";
		cin >> cm;
		calcMetersCm(meters, cm, feet, inches);
		cout << meters << " m and " << cm << "cm = "
					 << feet << "ft and " << inches << "in\n";
	}
	else {
		cout << "Error: improper selection";
	}
}


void calcFeetInches(double feet,double inches,double &meters,double &cm)
{
    meters = feet* 0.3048 + (inches*0.0254);
     cm=(feet*30.48+inches*2.54);
}

void calcMetersCm(double meters, double cm, double &feet, double &inches)
{
  feet = (meters/0.3048)+(cm/30.48);
  inches = (meters/0.0254)+(cm/2.54);
}

void calcPoundsOunces(double pounds, double ounces, double &kg, double &grams)
{
  kg= pounds*0.4536 + ounces*0.0283;
  grams= pounds*435.592 + ounces*28.3495;
}
void calcKgGrams(double kg, double grams,double &pounds, double &ounces)
{
pounds=(kg/0.4536)+(grams/453.592);
ounces=(kg/0.0283)+(grams/28.3495);
}
