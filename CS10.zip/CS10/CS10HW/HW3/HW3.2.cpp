#include <iostream>
#include <cmath>
using namespace std;
//Problem 2 on page 181 gives area and perimeter of triangle
int main(){
double area, perimeter, a, b, c;
//int a,b,c;
void compute(double&,double&,double,double,double);
cout<<"Enter 3 side lengths of triangle: "<<endl;
cout<<"Side 1: "<<endl;
cin>>a;
cout<<"Side 2: "<<endl;
cin>>b;
cout<<"Side 3: "<<endl;
cin>>c;

compute(area, perimeter,a,b,c);

return 0;
}

void compute (double& area, double& perimeter, double a, double b, double c) {
   double s;

   if( (a <= 0) || (b <= 0) || (c <= 0) )
    {
    cout<<"A triangle cannot have a side of zero or less!"<<endl;
    return;
    }
    else if( (a > (b + c)) || (b > (a + c)) || (c > (b + a)) )
    {
    cout<<"This combination will not make a legal triangle!"<<endl;
    return;
    }
   else
   {
   s = (a + b + c)/ 2.0;
   area = sqrt (s*(s-a)*(s-b)*(s-c));
   perimeter = (a + b + c);
   cout << "Area: " << area <<" " << "Perimeter: "<< perimeter << endl;

   }
   return;
}
