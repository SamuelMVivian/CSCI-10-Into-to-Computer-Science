#include <iostream>

using namespace std;

void input(int&, int&, char&);
void convert(int&, int&, char&);
void output(int&, int&, char&);
//Problem 1 on page 181 coverts 24 hour to 12 hour time
int main(){

  int hours, minutes;
  char ampm;
  char again;

  do{
    input(hours, minutes, ampm);
    convert(hours, minutes, ampm);
    output(hours, minutes, ampm);

    cout<<"Enter Y to run again, any other key to exit: ";
    cin>>again;
  }
  while(again == 'y'|| again == 'Y');
  return 0;
  }

  void input(int& hours, int& minutes, char& ampm)
  {

  	do
  	{
  		cout << "Enter hours: ";
  		cin >> hours;
  		if(hours > 23 || hours < 0) cout << "Please enter a value between 0 and 23" << endl;
  	}
  	while(hours > 23 || hours < 0);

  	do
  	{
  		cout << "Enter minutes: ";
  		cin >> minutes;
  		if(minutes > 59 || minutes < 0) cout << "Please enter a value between 0 and 59" << endl;
  	}
  	while(minutes > 59 || minutes < 0);
  }

  void convert(int& hours, int& minutes, char& ampm)
  {
  	if(hours > 12)
  	{
  		hours = hours - 12;
  		ampm = 'p';
  	}
  	else if(hours == 12) ampm = 'p';
  	else ampm = 'a';
  }

  void output(int& hours, int& minutes, char& ampm)
  {
  	if(ampm == 'p')
  	{
  		if(minutes < 10) cout << hours << ":0" << minutes << " P.M.";
  		else cout << hours << ":" << minutes << " P.M.";
  	}
  	else
  	{
  		if(minutes < 10) cout << hours << ":0" << minutes << " A.M."; //adds leading 0 if minutes is 1-9
  		else cout << hours << ":" << minutes << " A.M.";
  	}
  }
