#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

void averageWords (ifstream &fin);

int main ()
{
  string filename;
  cout<<"Enter the filename: ";
  cin>>filename;
  ifstream finput;
  finput.open(filename.c_str());
  if (finput.fail())
  {
    cout<<"could not open file";
    exit (1);
  }
  averageWords (finput);
  finput.close();
  cin.get();
  return 0;
}
void averageWords (ifstream& fin)
{
  int count = 0, totalLength=0;
  double average;
  char next;
  while (!fin.eof())
  {
    int wordLength = 0;
    fin.get(next);
    while (next!=' ' && next != '\n' && next != ',' && next !='.')
    {
      wordLength++;
      cout<<next;
      fin.get(next);
      if (next==' '||next == ' ' || next == '\n' || next =='.')
      {
        count ++;
      }
    }
    cout<<next;
    totalLength+=wordLength;
  }
  average = (double)totalLength/count;
  cout<<"Total Length of words: "<<totalLength<<endl;
  cout<<"Number of words in a file: "<<count<< endl;
  cout<<"agerage length for each word: "<<average<<endl;
}
