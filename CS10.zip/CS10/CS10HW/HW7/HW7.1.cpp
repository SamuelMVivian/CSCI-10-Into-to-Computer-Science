#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
using namespace std;
const int TOTAL_SUBJECTS=10;
void result (ifstream& fin, ofstream& fout);
int main()
{
  ifstream fin;
  ofstream fout;
  fin.open("record.txt");
  fout.open("result.txt");
  result (fin, fout);
  fin.close();
  fout.close ();
  return 0;
}

void result (ifstream&fin, ofstream&fout)
{
  while(!fin.eof())
  {
    float average;
    int total=0, i;
    string lastname, firstname;
    int subject [TOTAL_SUBJECTS];
    fin>>lastname>>firstname;
    fout << lastname << " " << firstname << " ";

    for (i=0; i<10; i++)
    {
      fin>>subject[i];
      fout<<subject[i]<<" ";
      total+=subject[i];
    }
    average=(float)total/i;
    fout<<average<<endl;
  }
}
