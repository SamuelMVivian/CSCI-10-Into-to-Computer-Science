#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <iomanip>
using namespace std;

void compute(ifstream& fin, ofstream& fout);
void description(ofstream& fout);
void copy (ifstream&fin, ofstream&fout);

int main()
{
  string sourcefile, destfile;
  cout<< "Enter the file name to input from: ";
  cin>>sourcefile;
  cout <<"Enter the file name to store the output: ";
  cin>>destfile;
  ifstream fin;
  ofstream fout;
  fin.open(sourcefile.c_str());
  if(fin.fail())
  {
    cout<<"File not found";
    exit(1);
  }
  fout.open(destfile.c_str());
  description(fout);
  compute(fin, fout);
  fin.close();
  fout.close();
  fin.open(destfile.c_str());
  fout.open(sourcefile.c_str());
  copy(fin, fout);
  fin.close();
  fout.close();

  return 0;
}
void description(ofstream&fout)
{
  fout<<"This program reads scores of each student and compute average of each student" << endl << "Compute average by adding all scores and it by 10."<<endl << " copy the contents of destination file into source file to chnage the content of input file "<<endl;
  fout<< endl << endl;
}
void compute(ifstream& fin, ofstream&fout)
{
  char next;
  int score;
  float average;
  string firstname, lastname;
  while (!fin.eof())
  {
    int total=0, count=0;
    fin >> lastname;
    fout << setw(10)<<lastname;
    fin >> firstname;
    fout << setw(10) << firstname << " ";
    do{
      fin >> score;
      count++;
      fout << setw(5) << score;
      total+=score;
      fin.get(next);
    } while (next!='\n'&&(!fin.eof()));
    while(count<10)
    {
      fout <<setw(5)<<0;
      count ++;
    }
    cout <<"total: " <<total <<endl;
    average=(float) total/10;
    fout.setf(ios::fixed);
    fout.setf (ios:: showpoint);
    fout.precision(2);
    cout<<"Average: "<<average << endl;
    fout << setw(7)<<average<<endl;
  }
}
void copy(ifstream& fin, ofstream& fout)
{
  char next;
  int count=0;
  fin.get(next);
  cout<<next;
  do
  {
    do
    {
      fout<< next;
      cout<<next;
      fin.get(next);
    }while(next!='\n');
    fout<<next;
    fin.get(next);
  }while(next!='\n');
  fout<<next;
  string lastname, firstname;
  int score[10];
  double average;
  do {
    fin>>lastname;
    fout<<setw(10)<<firstname;
    for(int i=0; i<10; i++){
      fin>>score[i];
      fout<<setw(5)<<score[i];
    }
    fin>>average;
    fout.setf(ios::fixed);
    fout.setf(ios::showpoint);
    fout.precision(2);
    fout << setw(7)<<average<< endl;
  } while(!fin.eof());
}
