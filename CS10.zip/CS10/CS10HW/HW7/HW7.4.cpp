#include<iostream>
#include <fstream>
#include<string>
#include<string>
using namespace std;

void correct(ifstream&fin, ofstream&fout);
int main()
{
  ifstream fin;
  ofstream fout;
  string sourcefile, destfile;
  cout<<"Enter the c++ filename : ";
  cin>>sourcefile;
  cout<<"Enter the filename to output the c++ program: ";
  cin>> destfile;
  fin.open(sourcefile.c_str());
  if (fin.fail())
  {
    cout<< "File not fount";
    exit(1);
  }
  fout.open(destfile.c_str());
  correct(fin, fout);
  fin.close();
  fout.close();
  return 0;
}

void correct(ifstream& fin, ofstream&fout)
{
  char next;
  fin.get(next);
  while(!fin.eof())
  {
    if (next=='c')
    {
      fout<<next;
      fin.get(next);
      if (next=='i')
      {
        fout<<next;
        fin.get(next);
        if (next=='n')
        {
          fout<<next;
          fin.get(next);
          while (next!=';')
          {
          if(next=='<')
          {
            fin.get(next);
            if(next=='<')
              fout<<">>";
            else
              fout<<next;
        }
        else
          fout<<next;
        fin.get(next);
      }
    }
  }
  if(next=='o')
  {
    fout<<next;
    fin.get(next);
    if(next=='u')
    {
      fout<<next;
      fin.get(next);
      if(next=='t')
      {
        fout<<next;
        fin.get(next);
        while(next!=';')
        {
          if(next=='>')
          {
          fin.get(next);
          if (next=='>')
            fout<<"<<";
          else
            fout<<next;
        }
        else
          fout<<next;
        fin.get(next);
      }
    }
  }
}
}
fout<<next;
fin.get(next);
}
}
