// problem 2 pg 419

#include <iostream>

using namespace std;

const int MAX = 101;
void countWords(char p[], int &size);
void countLetters(char p[], int &size);

int main(){

  int size;
  char phrase[MAX];
  cout << "Enter line of text: ";
  cin.getline(phrase, MAX);

  countWords(phrase, size);
  countLetters(phrase,size);


  return 0;
}

void countWords(char p[], int &size)
{
     int count=0;
     for (int i = 0; i < strlen(p); i++)
     {
          if ((p[i] !=' '&&p[i]!='.'&&p[i]!=',')&&(p[i+1]==' '||p[i+1]=='.'||p[i+1]==','))
          {
            count=count+1;
          }
      }
      if(p[strlen(p)-1]!=' '&&p[strlen(p)-1]!='.'&&p[strlen(p)-1]!=','){
        count=count+1;
      }
cout<<count<<" words"<<endl;
}

void countLetters(char p[], int &size)
{
  int countA=0, countB=0, countC=0, countD=0, countE=0, countF=0, countG=0, countH=0, countI=0, countJ=0, countK=0, countL=0, countM=0, countN=0, countO=0, countP=0, countQ=0, countR=0, countS=0, countT=0, countU=0, countV=0, countW=0, countX=0, countY=0, countZ=0;
  for (int i = 0; i < strlen(p); i++){
    if(p[i]=='a'||p[i]=='A'){
      countA=countA+1;
    }
    if(p[i]=='b'||p[i]=='B'){
      countB=countB+1;
    }
    if(p[i]=='c'||p[i]=='C'){
      countC=countC+1;
    }
    if(p[i]=='d'||p[i]=='D'){
      countD=countD+1;
    }
    if(p[i]=='e'||p[i]=='E'){
      countE=countE+1;
    }
    if(p[i]=='f'||p[i]=='F'){
      countF=countF+1;
    }
    if(p[i]=='g'||p[i]=='G'){
      countG=countG+1;
    }
    if(p[i]=='h'||p[i]=='H'){
      countH=countH+1;
    }
    if(p[i]=='i'||p[i]=='I'){
      countI=countI+1;
    }
    if(p[i]=='j'||p[i]=='J'){
      countJ=countJ+1;
    }
    if(p[i]=='k'||p[i]=='K'){
      countK=countK+1;
    }
    if(p[i]=='l'||p[i]=='L'){
      countL=countL+1;
    }
    if(p[i]=='m'||p[i]=='M'){
      countM=countM+1;
    }
    if(p[i]=='n'||p[i]=='N'){
      countN=countN+1;
    }
    if(p[i]=='o'||p[i]=='O'){
      countO=countO+1;
    }
    if(p[i]=='p'||p[i]=='P'){
      countP=countP+1;
    }
    if(p[i]=='q'||p[i]=='Q'){
      countQ=countQ+1;
    }
    if(p[i]=='r'||p[i]=='R'){
      countR=countR+1;
    }
    if(p[i]=='s'||p[i]=='S'){
      countS=countS+1;
    }
    if(p[i]=='t'||p[i]=='T'){
      countT=countT+1;
    }
    if(p[i]=='u'||p[i]=='U'){
      countU=countU+1;
    }
    if(p[i]=='v'||p[i]=='V'){
      countV=countV+1;
    }
    if(p[i]=='w'||p[i]=='W'){
      countW=countW+1;
    }
    if(p[i]=='x'||p[i]=='X'){
      countX=countX+1;
    }
    if(p[i]=='y'||p[i]=='Y'){
      countY=countY+1;
    }
    if(p[i]=='z'||p[i]=='Z'){
      countZ=countZ+1;
    }
  }
if(countA>0){
  cout<<countA<<" a"<<endl;
}
if(countB>0){
  cout<<countB<<" b"<<endl;
}
if(countC>0){
  cout<<countC<<" c"<<endl;
}
if(countD>0){
  cout<<countD<<" d"<<endl;
}
if(countE>0){
  cout<<countE<<" e"<<endl;
}
if(countF>0){
  cout<<countF<<" f"<<endl;
}
if(countG>0){
  cout<<countG<<" g"<<endl;
}
if(countH>0){
  cout<<countH<<" h"<<endl;
}
if(countI>0){
  cout<<countI<<" i"<<endl;
}
if(countJ>0){
  cout<<countJ<<" j"<<endl;
}
if(countK>0){
  cout<<countK<<" k"<<endl;
}
if(countL>0){
  cout<<countL<<" l"<<endl;
}
if(countM>0){
  cout<<countM<<" m"<<endl;
}
if(countN>0){
  cout<<countN<<" n"<<endl;
}
if(countO>0){
  cout<<countO<<" o"<<endl;
}
if(countP>0){
  cout<<countP<<" p"<<endl;
}
if(countQ>0){
  cout<<countQ<<" q"<<endl;
}
if(countR>0){
  cout<<countR<<" r"<<endl;
}
if(countS>0){
  cout<<countS<<" s"<<endl;
}
if(countT>0){
  cout<<countT<<" t"<<endl;
}
if(countU>0){
  cout<<countU<<" u"<<endl;
}
if(countV>0){
  cout<<countV<<" v"<<endl;
}
if(countW>0){
  cout<<countW<<" w"<<endl;
}
if(countX>0){
  cout<<countX<<" x"<<endl;
}
if(countY>0){
  cout<<countY<<" y"<<endl;
}
if(countZ>0){
  cout<<countZ<<" z"<<endl;
}
}
