//problem 9 pg 239
#include <iostream>

void displayBoard(char board[3][3]){
   using namespace std;
   for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
         cout << board[i][j];
         if (j < 2) cout << ' ';
      }
      cout << endl;
   }
}

bool isInWinningConfiguration(char board[3][3], char player){
   bool vWin, hWin, d1Win, d2Win;
   d1Win = true; // diagonal 1
   d2Win = true; // diagonal 2
   for (int i = 0; i < 3; ++i) {
      vWin = true; // vertical
      hWin = true; // horizontal
      // check for vertical or horizontal wins
      for (int j = 0; j < 3; ++j) {
         // if any space is not held by player then
         // that column/row does not represent a win
         if (board[i][j] != player) vWin = false;
         if (board[j][i] != player) hWin = false;
         // if we already lost in this column AND this row, then stop checking
         if(!(hWin || vWin)) break;
      }
      // if we won in the column or the row we just checked, then we can return true (a win)
      if (vWin || hWin) return true;

      // check both diagonals. If the player is missing any space, then it's not a winner.
      if(board[i][i] != player) d1Win = false;
      if(board[i][2-i] != player) d2Win = false;
   }
   // if we won on either of the diagonals, return true
   if (d1Win || d2Win) return true;

   return false;
}


int main()
{
   using namespace std;

   char board[3][3] = {
      {'1','2','3'},
      {'4','5','6'},
      {'7','8','9'}
   };

   char players[2] = {'X','O'};
   int player = 0;
   int turn = 0;

   while(++turn){
      // display the board
      displayBoard(board);

      // if the current player has won, then give a message and exit
      // we take advantage of short-circuit evaluation to only check if the board is in
      // a winning config after the 5th turn (before this no player has had three turns)
      if(turn > 5 && isInWinningConfiguration(board, players[player])){
         cout << endl << "Congratulations " << players[player] << " you won!" << endl << endl;
         return 0;
      }

      if(turn == 10){
         cout << endl << "Tie" << endl << endl;
         return 0;
      }

      // switch players
      player = (player + 1) % 2;

      // get the players initial move
      int move;
      cout <<  players[player] << "'s turn: ";
      cin >> move;
      move -= 1; // we need it to be zero-indexed

      // make sure that the move is a legal one (cell not already taken)
      // if it's not legal, request a new move.
      while(1){
         char * cell = &board[move/3][move%3];
         if(move > 8 || move < 0){
            cout << "\tyour move must be between 1 and 9: ";
         }else if(*cell == players[0] || *cell == players[1] ){
            cout << "\tthat move is taken, please choose another: ";
         }else{
            *cell = players[player];
            break;
         }
         cin >> move;
         move -= 1;
      }
   }

   // we should never get here
   return 0;
}
