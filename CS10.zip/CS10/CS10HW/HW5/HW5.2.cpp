//problem 1 pg 419
#include <iostream>
#include <cstdlib>
#include <cctype>
using namespace std;

const int MAX = 101;
void clearPhrase(char p[], int &size);
void capitalize(char p[]);
void deleteSpaces(char p[], int &size);
void lowercase(char p[]);
int main()
{
    char phrase[MAX], space1, space2, ans;
    int size, i;

    clearPhrase(phrase, size);

    cout << "Enter phrase: ";
    cout << phrase;
    cin.getline(phrase, MAX);

    capitalize(phrase);
    lowercase(phrase);
    deleteSpaces(phrase, size);
    cout<<endl;
    return 0;
}
void clearPhrase(char p[], int &size)
{
    p[0] = '\0';
    size = 0;
}
//makes first letter of the sentence capital.
void capitalize(char p[])
{
     if (p[0] != ' ')
        p[0] = toupper(p[0]);

}
//deletes extra spaces.
void deleteSpaces(char p[], int &size)
{
     //used to tell us if there is a blank space.
     bool found = false;

     //goes through whole string.
     for (int i = 0; i < strlen(p); i++)
     {
            if (p[i] != ' ')
            {
                //if a character isn't a space, output it.
                cout << p[i];
                //tells program that we didn't find it.
                found = false;
            }

            if(p[i] == ' ' && found == false)
            {
                //blank space is found, so display only one blank space.
                found = true;
                cout << " ";
            }
     }
}
//makes all letters within the sentence lowercase.
void lowercase(char p[])
{
     for (int i = 1; i < strlen(p); i++)
     {
         p[i] = tolower(p[i]);
     }
}
