#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>
using namespace std;
//computes average sore on a quiz given an undefined quantity of inputs
//also adds maximum score cap
//also gives min and max score
void scores(int a[], int size, int &numberUsed);
double average (const int a[], int numberUsed);
void output (const int a[], int numberUsed);
const int maxScore = 900;
double max = 0;
double min=30;

int main(){
double scoreTotal=0;
double score;
double avg;
double max=-1;
double min=31;
int i=0;

while(score != -1){
  cout<<"Enter score: ";
  cin>>score;
  if((score !=- 1) && (score<=30) && (score > -1)){
      scoreTotal = scoreTotal + score;
      if (score>max) max=score;
      if (score<min) min=score;
      i++;
  }else if(score>30||score < -1){
    cout<<"Invalid score"<<endl;
  }
  }
  avg = scoreTotal/i;
  cout<<"Average: "<<avg<<endl;
  cout<<"Minimum: "<<min<<endl;
  cout<<"Maximum: "<<max<<endl;
return 0;
}
