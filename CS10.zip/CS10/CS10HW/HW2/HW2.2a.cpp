#include <iostream>

using namespace std;
//outputs requested sequences
int main(){
for(int i=0; i<5; i++){
  cout<<"start ";
  for(int j=0; j<8; j++){
    if(i>=j){
      cout<<"o";
    }else{
      cout<<"x";
    }
  }
  cout<<" end"<<endl;
}

}
