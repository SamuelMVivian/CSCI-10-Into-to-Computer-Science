#include <iostream>
#include <cmath>

using namespace std;
//probelm 4 page 140 calculates gravitational force between two masses
const double G = 6.673*(pow(10,-8));
void force();
int main(){
  force();
  }

void force(){
  double m1,m2,d,F;
  while (true){
    cout<<"enter mass 1 in grams "<<endl;
    cin>>m1;
    cout<<"enter mass 2 in grams "<<endl;
    cin>>m2;
    cout<<"enter distance in cm "<<endl;
    cin>>d;
    F=(G*m1*m2)/(pow(d,2));
    cout<<F<<endl;
  }
}
