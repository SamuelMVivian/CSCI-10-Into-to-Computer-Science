#include <iostream>
using namespace std;
//computes average sore on a quiz given an undefined quantity of inputs
//also adds maximum score cap
int main(){
double scoreTotal=0;
double score;
double avg;
int i=0;

while(score != -1){
  cout<<"Enter score: ";
  cin>>score;
  if((score !=- 1) && (score<=30)&& (score > -1)){
      scoreTotal = scoreTotal + score;
      i++;
  }else if(score>30||score < -1){
    cout<<"Invalid score"<<endl;
  }
  }
  avg = scoreTotal/i;
  cout<<avg<<endl;
return 0;
}
