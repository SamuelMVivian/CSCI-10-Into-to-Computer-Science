#include <iostream>
#include <cmath>

using namespace std;
//Problem 7 on page 141 calculates wind chill
void windChill();
int main(){
  windChill();
  }

void windChill(){
  double v,t,W;
    cout<<"enter wind speed in m/sec "<<endl;
    cin>>v;
    cout<<"enter temperature in Celsius: t<=10 "<<endl;
    cin>>t;
    W=33-((10*sqrt(v)-v+10.5)*(33-t))/23.1;
    if(t>10){
      cout<<"invalid temperature entry"<<endl;
    }else{
    cout<<W<<endl;
  }
}
