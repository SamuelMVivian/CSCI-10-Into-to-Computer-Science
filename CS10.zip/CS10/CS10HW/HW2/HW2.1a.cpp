#include <iostream>
using namespace std;
//computes average sore on a quiz given an undefined quantity of inputs
int main(){
double scoreTotal=0;
double score;
double avg;
int i=0;

while(score != -1){
  cout<<"Enter score: ";
  cin>>score;
  if(score !=- 1){
      scoreTotal = scoreTotal + score;
      i++;
    }
  }
  avg = scoreTotal/i;
  cout<<avg<<endl;
return 0;
}
