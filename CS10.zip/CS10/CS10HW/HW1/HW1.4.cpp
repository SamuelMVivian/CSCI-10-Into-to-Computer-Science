#include <iostream>
#include <cmath>
using namespace std;
//fixed triangle code
int main(){
double a; //cannot declare all variable at once needs to be three separate declaratons
double b;
double c;
double intermediate;

b=2; //cannot assign 2=b
cout<<"Enter length of hypotenuse"<<endl;
cin>>c;//no endl on cin
cout<<"Enter length of a side"<<endl; //arrows in wrong direction
cin>>a;
intermediate = pow(c, 2)-pow(a, 2); //variable shouldbe declared at he beginning
b = sqrt(intermediate);
cout<<"Length of other side is: "<<b<<endl; // add double hours and endl not endline
return 0;
}
