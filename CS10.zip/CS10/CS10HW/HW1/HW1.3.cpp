#include <iostream>
using namespace std;
//problem 7 pg 44 calculates calories burned using time weight and METS
int main(){
double weight;
double time;
double mets;
double caloriesBurned;

cout<<"Enter your weight in pounds: "<<endl;
cin>>weight;
cout<<"Enter METS for activity: "<<endl;
cin>>mets;
cout<<"Enter time in minutes: "<<endl;
cin>>time;

caloriesBurned = 0.0175*mets*(weight/2.2)*time;

cout<<caloriesBurned<<endl;
return 0;
}
