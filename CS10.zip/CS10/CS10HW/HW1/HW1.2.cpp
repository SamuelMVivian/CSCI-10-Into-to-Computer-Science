#include <iostream>
using namespace std;
//problem 7 pg 43 Find amount of soda that would kill a person based on weight and amount needed to kill a mouse
int main(){
double goalWeight;
double mouseWeight;
double sweetenerToKillMouse;
double sweetenerToKill;
double maxSodas;
const double sweetenerConcentration = 0.001;

cout<<"Enter dieting weight goal: "<<endl;
cin>>goalWeight;
cout<<"Enter mouse weight: "<<endl;
cin>>mouseWeight;
cout<<"Enter amount of sweetener needed to kill the mouse : "<<endl;
cin>>sweetenerToKillMouse;

sweetenerToKill=(goalWeight*sweetenerToKillMouse)/mouseWeight;
maxSodas=sweetenerToKill/sweetenerConcentration;

cout<<maxSodas<<endl;
return 0;
}
