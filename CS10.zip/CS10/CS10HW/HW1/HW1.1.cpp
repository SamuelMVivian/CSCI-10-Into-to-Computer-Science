#include <iostream>
using namespace std;
//converts gallons to liters
int main(){
double gallons;
double liters;

cout<<"Enter gallon amount: "<<endl; //prompts user to enter gallons
cin>>gallons; //stores in gallons

liters=(gallons*3.78541); //calculates liters

cout<<liters<<endl; //outpts liters
return 0;
}
