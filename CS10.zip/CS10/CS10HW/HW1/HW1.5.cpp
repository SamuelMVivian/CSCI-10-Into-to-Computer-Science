#include <iostream>
using namespace std;
//code takes in day of the week and outputs a corresponding schedule
int main(){
char day; //declared day as string
cout<<"Enter day of the week  (M, T, W, H or F: "<<endl; //requests inout of day of the week
cin>>day;
switch (day) //for each day of the week outputs schedule
{
case 'M':
 cout<<"CSCI 10 at 1:00, PHIL 11A at 2:15, MATH 12 at 4:45"<<endl;
 break;
case 'T':
 cout<<"PHYS 2 at 12:10, CSCI 10 lab at 2:15"<<endl;
 break;
case 'W':
 cout<<"CSCI 10 at 1:00, PHIL 11A at 2:15, MATH 12 at 4:45"<<endl;
 break;
case 'H':
 cout<<"PHYS 2 at 12:10"<<endl;
 break;
case 'F':
 cout<<"CSCI 10 at 1:00, PHIL 11A at 2:15, MATH 12 at 4:45"<<endl;
 break;
default:
 cout<<"That is not a valid day of the week"<<endl;
}
 return 0;
}
