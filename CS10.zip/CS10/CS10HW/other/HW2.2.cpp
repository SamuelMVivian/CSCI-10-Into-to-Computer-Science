#include <iostream>
using namespace std;
//problem 4 pg 96 lists all primes from 3 to 100;
int main(){

int count;
int prime;

for (count=2; count<100; count++){
  for(prime=2; prime<count; prime++){
    if (count % prime == 0)
    break;
    else if (count == prime + 1)
    cout<<count<<endl;
  }
}
 return 0;
}
