#include <iostream>
using namespace std;
//problem 1 pg 95 takes in cost years and rate of inflation and gives estimated cost
int main(){
double cost;
double years;
double rate;
double percent;
double i;

cout<<"Enter item cost: "<<endl;
cin>>cost;
cout<<"Enter years from now item will be purchased: "<<endl;
cin>>years;
cout<<"Enter inflation rate as a percentage: "<<endl;
cin>>percent;

rate = percent/100;

i=1;

while (i<=years){
  cost=cost+cost*rate;
  i++;
}
cout<<cost<<endl;
 return 0;
}
