#include <iostream>
#include <string>
using namespace std;
//helps organize the activities of your cousins;
int main(){

string name;
int age;
double height;

cout<<"Enter name: "<<endl;
cin>>name;
cout<<"Enter age: "<<endl;
cin>>age;
cout<<"Enter height in inches: "<<endl;
cin>>height;

if (name == "Katie"){
  cout<<"Winchester Mystery House"<<endl;
}else if ((age>=12)&&(height>=60)){
  cout<<"Great America"<<endl;
}else if ((age<12)&&(height>=60)){
  cout<<"carnival"<<endl;
}else{
  cout<<"Chuck E. Cheese"<<endl;
}

 return 0;
}
