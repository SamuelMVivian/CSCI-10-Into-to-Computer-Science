# include <iostream>
#include <string>

using namespace std;

void findprotein(string dna, string protein);

int main(){
string dna;
string protein;
//int start, length;
cout<<"enter a dna string: "<<endl;
getline(cin,dna);
cout<<"enter desired protein: "<<endl;
getline(cin,protein);

findprotein(dna,protein);

return 0;
}

void findprotein(string dna, string protein){
  bool found;
  for(int i=0;i<=dna.length();i++){
    if(dna[i]==protein[0]&&dna[i+1]==protein[1]&&dna[i+2]==protein[2]&&dna[i+3]==protein[3]){
      found =true;
      cout<<"Protein found at "<<i<<endl;
      break;
    }else{
      found=false;
    }
}
if(found==false){
cout<<"not found"<<endl;
}
}
