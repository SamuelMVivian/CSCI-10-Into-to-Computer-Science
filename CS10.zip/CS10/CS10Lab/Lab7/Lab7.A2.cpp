# include <iostream>
#include <string>

using namespace std;

void substring(string word, int start, int length);

int main(){
string word;
int start, length;
cout<<"enter a word: "<<endl;
getline(cin,word);
cout<<"enter starting point: "<<endl;
cin>>start;
cout<<"enter desired number of characters: "<<endl;
cin>>length;

substring(word, start, length);

return 0;
}

void substring(string word, int start, int length){
  string sub;
  int j=0;
  for(int i=start;i<=start+length;i++){
    sub[j]=word[i];
    j++;
  }
  for(int i=0;i<=length-1;i++){
  cout<<sub[i];
}
cout<<endl;
}
