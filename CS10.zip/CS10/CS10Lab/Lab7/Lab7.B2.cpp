# include <iostream>
#include <string>

using namespace std;

void encrypt(string in, int shift);

int main(){
string in;
int shift;

cout<<"enter a word: "<<endl;
getline(cin,in);
cout<<"enter shift: "<<endl;
cin>>shift;

encrypt(in,shift);

return 0;
}

void encrypt(string in, int shift){
  string out;
  for(int i=0;i<=in.length();i++){
    out[i]=int(in[i])+shift;
    if(out[i]+shift>122){
      out[i]=out[i]-26;
    }
    out[i]=char(out[i]);
  }
  for(int i=0;i<=in.length();i++){
    cout<<out[i];
  }
  cout<<endl;
}
