#include <iostream>
#include <string>
#include <fstream>

using namespace std;

double average(double arr[], int size);

int main(){

int n=0;
double ave;
double scores[900];

ifstream file;
file.open("scores.txt");

while(!file.eof()){
  file>>scores[n];
  n++;
}

ave=average(scores,n);
file.close();

ofstream write;
write.open("write.txt");
write<<"Average: "<<ave<<endl<<"Scores above average: "<<endl;
for(int i=0; i<n;i++){
  if(scores[i]>ave){
    write<<scores[i]<<endl;
  }
}
write.close();
  return 0;
}


double average(double arr[], int size){
 double total=0;
 for(int i=0; i<size; i++){
 total=total+arr[i];
 }
 return total/size;
}
