#include <iostream>
#include <string>
#include <fstream>
using namespace std;

struct StudentInfo{
  string fname;
  string lname;
  string year;
  string GPA;
};

int main(){
StudentInfo Student[900];
int n=0;

ifstream file;
file.open("studentlist.txt");

while(!file.eof()){
  getline(file,Student[n].fname,' ');
  cout<<Student[n].fname<<endl;
  getline(file,Student[n].lname);
  cout<<Student[n].lname<<endl;
  getline(file,Student[n].year);
  cout<<Student[n].year<<endl;
  getline(file,Student[n].GPA);
  cout<<Student[n].GPA<<endl;
  n++;
}

file.close();

  return 0;
}
