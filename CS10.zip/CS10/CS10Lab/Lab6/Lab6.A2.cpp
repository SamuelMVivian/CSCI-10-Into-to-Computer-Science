#include <iostream>

using namespace std;
void minArray();

int main(){
cout<<minArray()<<endl;
return 0;
}

void minArray(){
  int a[100], n, i, min;
    cout << "Enter the size of the array : "<<endl;
    cin >> n;
    cout << "Enter the elements of the array : "<<endl;
    for (i = 0; i < n; i++){
        cin >> a[i];
      }
      min = a[0];
    for (i=0;i<n;i++){
      if(min>a[i]){
        min=a[i];
      }
    }
    return min;
}
