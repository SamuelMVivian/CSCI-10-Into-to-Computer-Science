#include <iostream>
#include <cstring>
#include <string>
#include <time.h>

using namespace std;

void learnSpanish();

int main(){
  learnSpanish();
  return 0;
}

void learnSpanish(){
string spanish[5] = {"gato","perro", "uno", "dos", "tres"};
string english[5] = {"cat", "dog", "one", "two", "three"};
int score[5] = {0,0,0,0,0};
int correct =0;
int attempts =0;
string answer;
srand(time(NULL));

while(correct<10){
  int index = rand()%5;
  if(score[index]<2){
    cout<<"What is the English of "<<spanish[index]<<endl;
    cin>>answer;
    if(answer==english[index]){
      correct++;
      score[index]=score[index]+1;
    }else{
      cout<<"The right answer is "<<english[index]<<endl;
    }
    attempts++;
    }
  }
  cout<<"No. of attempts: "<<attempts<<endl;
}
