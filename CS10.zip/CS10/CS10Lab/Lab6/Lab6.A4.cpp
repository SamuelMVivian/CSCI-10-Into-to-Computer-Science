#include <iostream>

using namespace std;
void factarr(int a[], bool fact[], int size);
bool isfact(int n);

const int maxSize=900;
int main(){
  int size;
  int i;
  int a[maxSize];
  bool b[maxSize];
  cout << "Enter the size of the array : "<<endl;
  cin >> size;
  cout << "Enter the elements of the array : "<<endl;
  for (i = 0; i < size; i++){
      cin >> a[i];
}
factarr(a,b,size);
return 0;
}

void factarr(int a[], bool fact[], int size){
  for(int i=0; i < size; i++){
    if(isfact(a[i])==true){
      fact[i]=true;
    }else{
      fact[i]=false;
    }
  }
  for(int i=0;i<size;i++){
  cout<<a[i]<< " "<<fact[i]<<endl;
}
}
bool isfact(int n){
  bool is=false;
  int fact=1;
    for(int i=1; i<n+1; i++){
      fact=fact*i;
        if(fact==n)
        is=true;
      }
  return is;
}
