#include <iostream>

using namespace std;

void factors(int n, int fact[]);

int main(){
 int a[50];
 int test = 0;
 cout<<"Enter a number!"<<endl;
 cin>>test;
 if(test>=50){
 cout<<"Sorry! Can't test numbers that high!"<<endl;
 }
 else{
 factors(test, a);
 }
 return 0;
}

void factors(int n, int fact[]){
  bool b[50];
  fact[0]=0;
  b[0]=0;
  for(int i=1;i<n;i++){
    fact[i]=i;
    if(n%i==0){
      b[i]=true;
    }else{
      b[i]=false;
    }
  }
  for(int i=0;i<n;i++){
  if(b[i]==true){
  cout<<fact[i]<<endl;
}
}
}
