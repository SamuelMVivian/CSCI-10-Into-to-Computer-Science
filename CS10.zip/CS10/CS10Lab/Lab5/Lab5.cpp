#include <iostream>

using namespace std;

void aveMax(double& a, double& b);

int main(){
  double max=-1;
  double ave=0;
aveMax(ave,max);
}

void aveMax(double& a, double& b){
  double val = 0, total = 0, count = 0, max=-1, ave=0;
  cout<<"Please enter a value, or -1 when you're done."<<endl;
  cin>>val;
  while(val!=-1){
    if(val>max){
      max=val;
    }
    total+=val;
    count++;
    cout<<"Please enter a value, or -1 when you're done."<<endl;
    cin>>val;
  }
  ave=total/count;
  cout<<"Average is: "<<ave<<" Max is: "<<max<<endl;
}
