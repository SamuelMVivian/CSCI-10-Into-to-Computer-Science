#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

struct Item{
  string name;
  string artist;
  double price;
  string chapters[100];
  string release;
};

void printItem1(Item it, int x);
void printItem(Item it,int x);
void initializeItem(Item &it, int &x);

int main(){
int x;
Item Item1;
initializeItem(Item1,x);
printItem(Item1,x);

return 0;
}

void initializeItem(Item &it,int &x){
cout<<"enter item name: "<<endl;
getline(cin,it.name);
cout<<"enter artist/author: "<<endl;
getline(cin,it.artist);
cout<<"enter price: "<<endl;
cin>>it.price;
cout<<"how many chapter/tracks are there?"<<endl;
cin>>x;
getline(cin,it.chapters[0]);
for(int i=0;i<x;i++){
  cout<<"enter chapter/track name: "<<endl;
  getline(cin,it.chapters[i]);
}
cout<<"enter release date"<<endl;
getline(cin,it.release);
}

void printItem(Item it, int x){
  //Item call;
  int a=0;
cout<<fixed;
cout<<setprecision(2);
cout<<"Item: "<<it.name<<", by "<<it.artist<<" for $"<<it.price<<endl;
cout<<"Would you like to purchase(1), see more details(2), or pass(3)"<<endl;
cin>>a;
if(a==1){
  cout<<"Thank you, have a nice day!"<<endl;
}else if(a==2){
  printItem1(it,x);
  cout<<"Would you like to purchase(1) or pass(3)"<<endl;
  cin>>a;
  if(a==1){
    cout<<"Thank you, have a nice day!"<<endl;
  }
}
}

void printItem1(Item it, int x){
cout<<fixed;
cout<<setprecision(2);
cout<<"Name: "<<it.name<<endl;
cout<<"Authot/Artist: "<<it.artist<<endl;
cout<<"Price: "<<it.price<<endl;
cout<<"Chapters/Tracks: "<<endl;
for(int i=0;i<x;i++){
  cout<<it.chapters[i]<<endl;
}
cout<<"Released: "<<it.release<<endl;

}
