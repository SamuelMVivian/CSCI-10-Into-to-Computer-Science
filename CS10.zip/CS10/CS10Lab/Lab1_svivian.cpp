#include <iostream>
using namespace std;

int main() {

  double sideLength = 44572637845;
  cout<<"Squarea is "<<sideLength*sideLength<<endl;
  return 0;
}
