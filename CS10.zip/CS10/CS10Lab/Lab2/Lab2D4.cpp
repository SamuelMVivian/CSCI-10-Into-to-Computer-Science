#include <iostream>
using namespace std;

int main(){
  string parent1; //declares parents at string variables
  string parent2;
  cout<<"Enter genotype for parent 1: "<<endl; //prompts user to ener two genotypes
  cin>>parent1;
  cout<<"Enter genotype for parent 2: "<<endl;
  cin>>parent2;
//for each if outputs the percentage chance that the child is each genotype
  if (parent1=="GG"&&parent2=="GG"){
      cout<<"100% GG"<<endl;
  }else if (parent1=="gg"&&parent2=="gg"){
      cout<<"100% gg"<<endl;
  }else if ((parent1=="GG"&&parent2=="gg")||(parent1=="gg"&&parent2=="GG")){
      cout<<"100% Gg"<<endl;
  }else if ((parent1=="GG"&&parent2=="Gg")||(parent1=="Gg"&&parent2=="GG")){
      cout<<"50% GG, 50% Gg"<<endl;
  }else if ((parent1=="gg"&&parent2=="Gg")||(parent1=="Gg"&&parent2=="gg")){
      cout<<"50% gg, 50% Gg"<<endl;
  }else if (parent1=="Gg"&&parent2=="Gg"){
      cout<<"50% Gg, 25% GG, 25% gg"<<endl;
  }else{
      cout<<"Invalid genotype entry"<<endl;
  }
  return 0;
}
