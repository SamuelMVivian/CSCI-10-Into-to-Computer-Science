#include <iostream>
using namespace std;

int main(){
char grade; //declared grade as a character
cout<<"Enter a grade: "<<endl; //requests inout of letter rade and stores it in grade
cin>>grade;
switch (grade) //for each letter grade case outputs a string that congratulates or scolds the student
{
case 'A':
 cout<<"Amazing job!"<<endl;
 break;
case 'B':
 cout<<"Great work!"<<endl;
 break;
case 'C':
 cout<<"You pass, good job."<<endl;
 break;
case 'D':
 cout<<"You pass, but barely"<<endl;
 break;
case 'F':
 cout<<"You need to improve!!"<<endl;
 break;
default:
 cout<<"That is not a valid grade"<<endl;
}
 return 0;
}
