#include <iostream>
using namespace std;

int main(){
  string parent1;
  string parent2;
  cout<<"Enter genotype for parent 1: "<<endl; //prompts user to enter a genotype for each parent
  cin>>parent1;
  cout<<"Enter genotype for parent 2: "<<endl;
  cin>>parent2;
// for each if statement outputs the percentage chance based on the parents that the child is of a give phenotype
  if ((parent1=="GG"&&parent2=="GG")||(parent1=="GG"&&parent2=="gg")||(parent1=="gg"&&parent2=="GG")||(parent1=="GG"&&parent2=="Gg")||(parent1=="Gg"&&parent2=="GG")){
      cout<<"100% Green"<<endl;
  }else if (parent1=="gg"&&parent2=="gg"){
      cout<<"100% Yellow"<<endl;
  }else if ((parent1=="gg"&&parent2=="Gg")||(parent1=="Gg"&&parent2=="gg")){
      cout<<"50% Yellow, 50% Green"<<endl;
  }else if (parent1=="Gg"&&parent2=="Gg"){
      cout<<"75% Green, 25% Yellow"<<endl;
  }else{
      cout<<"Invalid genotype entry"<<endl;
  }
  return 0;
}
