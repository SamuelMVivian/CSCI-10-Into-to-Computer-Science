#include <iostream>
#include <string>
using namespace std;

string genotype(char m1,char m2,char p1,char p2);

int main(){
  char a,b,c,d;
  cout<<"Please enter the two maternal alleles, one on each line"<<endl;
  cin>>a>>b;

  cout<<"Please enter the two paternal alleles, one on each line"<<endl;
  cin>>c>>d;

  cout<<genotype( a, b, c, d)<<endl;
  return 0;
}
string genotype(char m1,char m2,char p1,char p2){
double yy = 0, Yy = 0, YY = 0, invalid = 0;

if (m1=='Y' && p1=='Y')
    YY+=.25;
else if (((m1 == 'Y') && (p1 == 'y')) || ((m1 == 'y') && (p1 == 'Y')))
    Yy = Yy+.25;
else if (m1 == 'y' && p1 == 'y')
    yy = yy+.25;
else
    invalid = invalid +1;

if (m2=='Y' && p1=='Y')
    YY = YY+.25;
else if (((m2 == 'Y') && (p1 == 'y')) || ((m2 == 'y') && (p1 == 'Y')))
    Yy = Yy+.25;
else if (m2 == 'y' && p1 == 'y')
    yy = yy+.25;
else
    invalid = invalid +1;

if (m1=='Y' && p2=='Y')
    YY = YY+.25;
else if (((m1 == 'Y') && (p2 == 'y')) || ((m1 == 'y') && (p2 == 'Y')))
    Yy = Yy+.25;
else if (m1 == 'y' && p2 == 'y')
    yy = yy+.25;
else
    invalid = invalid +1;

if (m2=='Y' && p2=='Y')
    YY = YY+.25;
else if (((m2 == 'Y') && (p2 == 'y')) || ((m2 == 'y') && (p2 == 'Y')))
    Yy = Yy+.25;
else if (m2 == 'y' && p2 == 'y')
    yy = yy+.25;
else
    invalid = invalid +1;

if(invalid == 0)
    if(YY>Yy&&YY>yy){
      return "YY";
    }else if(Yy>yy&&Yy>YY){
      return "Yy";
    }else{
      return "yy";
    }
else
    return "Invalid input";

}
