#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int die(int n);

int main(){
srand(time(NULL));
cout<<die(20)<<endl;
return 0;
}

int die(int n){
  return((rand()%n+1));
}
