#include <iostream>
#include <string>
using namespace std;

double probability_genotype(char m1,char m2,char p1,char p2, string geno);

int main(){
  char a,b,c,d;
  string e;
  cout<<"Please enter the two maternal alleles, one on each line"<<endl;
  cin>>a>>b;

  cout<<"Please enter the two paternal alleles, one on each line"<<endl;
  cin>>c>>d;

  cout<<"Please enter target offspring allele"<<endl;
  cin>>e;

  cout<<probability_genotype( a, b, c, d, e)<<endl;
  return 0;
}
double probability_genotype(char m1,char m2,char p1,char p2, string geno){
double yy = 0, Yy = 0, YY = 0, invalid = 0;

if (m1=='Y' && p1=='Y')
    YY+=.25;
else if (((m1 == 'Y') && (p1 == 'y')) || ((m1 == 'y') && (p1 == 'Y')))
    Yy = Yy+.25;
else if (m1 == 'y' && p1 == 'y')
    yy = yy+.25;
else
    invalid = invalid +1;

if (m2=='Y' && p1=='Y')
    YY = YY+.25;
else if (((m2 == 'Y') && (p1 == 'y')) || ((m2 == 'y') && (p1 == 'Y')))
    Yy = Yy+.25;
else if (m2 == 'y' && p1 == 'y')
    yy = yy+.25;
else
    invalid = invalid +1;

if (m1=='Y' && p2=='Y')
    YY = YY+.25;
else if (((m1 == 'Y') && (p2 == 'y')) || ((m1 == 'y') && (p2 == 'Y')))
    Yy = Yy+.25;
else if (m1 == 'y' && p2 == 'y')
    yy = yy+.25;
else
    invalid = invalid +1;

if (m2=='Y' && p2=='Y')
    YY = YY+.25;
else if (((m2 == 'Y') && (p2 == 'y')) || ((m2 == 'y') && (p2 == 'Y')))
    Yy = Yy+.25;
else if (m2 == 'y' && p2 == 'y')
    yy = yy+.25;
else
    invalid = invalid +1;

    if(geno!="YY"&&geno!="Yy"&&geno!="yy"){
      invalid++;
    }

if(invalid == 0)
    if(geno=="YY"){
      return YY;
    }else if(geno=="Yy"){
      return Yy;
    }else if(geno=="yy"){
      return yy;
    }
else
    cout<<"Invalid input";

}
