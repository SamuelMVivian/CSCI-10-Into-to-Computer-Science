#include <iostream>

using namespace std;
//checks if number is even
bool is_even(int n);

int main(){
cout<<is_even(0)<<endl;
return 0;
}

bool is_even(int n){
  if(n%2==0){
  return true;
  }else{
  return false;
  }
}
