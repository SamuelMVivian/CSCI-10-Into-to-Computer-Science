#include <iostream>
using namespace std;
//outputs 0 0 0 3 2 1 6 4 2 9 6 3 12 8 4
int main(){
int i,j;

for(i=0;i<=4;i++){
  for(j=3;j>=1;j--){
    cout<<i*j<<" ";
  }
}
return 0;
}
