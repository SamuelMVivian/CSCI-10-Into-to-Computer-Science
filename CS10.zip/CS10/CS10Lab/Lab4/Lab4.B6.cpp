#include <iostream>

using namespace std;
//checks how many numbers between two given numbers are even
bool is_even(int n);
int evens_between(int n, int m);

int main(){
cout<<evens_between(1,10)<<endl;
return 0;
}

bool is_even(int n){
  if(n%2==0){
  return true;
  }else{
  return false;
  }
}

int evens_between(int n, int m){
  int x;
  for(int i=n; i<=m; i++){
    if(is_even(i)==true){
      x=x+1;
    }
  }
  return x;
}
