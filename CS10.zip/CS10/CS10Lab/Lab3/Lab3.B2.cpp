#include <iostream>
using namespace std;

int main(){


double yy = 0, Yy = 0, YY = 0, invalid = 0;
char m1, m2, p1, p2;

do{
invalid =0;
cout<<"Please enter the two maternal alleles, one on each line"<<endl;
cin>>m1>>m2;

cout<<"Please enter the two paternal alleles, one on each line"<<endl;
cin>>p1>>p2;

if (m1=='Y' && p1=='Y')
    YY+=.25;
else if (((m1 == 'Y') && (p1 == 'y')) || ((m1 == 'y') && (p1 == 'Y')))
    Yy = Yy+.25;
else if (m1 == 'y' && p1 == 'y')
    yy = yy+.25;
else
    invalid = invalid +1;

if (m2=='Y' && p1=='Y')
    YY = YY+.25;
else if (((m2 == 'Y') && (p1 == 'y')) || ((m2 == 'y') && (p1 == 'Y')))
    Yy = Yy+.25;
else if (m2 == 'y' && p1 == 'y')
    yy = yy+.25;
else
    invalid = invalid +1;

if (m1=='Y' && p2=='Y')
    YY = YY+.25;
else if (((m1 == 'Y') && (p2 == 'y')) || ((m1 == 'y') && (p2 == 'Y')))
    Yy = Yy+.25;
else if (m1 == 'y' && p2 == 'y')
    yy = yy+.25;
else
    invalid = invalid +1;

if (m2=='Y' && p2=='Y')
    YY = YY+.25;
else if (((m2 == 'Y') && (p2 == 'y')) || ((m2 == 'y') && (p2 == 'Y')))
    Yy = Yy+.25;
else if (m2 == 'y' && p2 == 'y')
    yy = yy+.25;
else
    invalid = invalid +1;

if(invalid == 0)
    cout<<"YY: "<<YY<<", Yy: "<<Yy<<", yy: "<<yy<<endl;
else
    cout<<"Invalid input"<<endl;
}while(invalid>0);
}
