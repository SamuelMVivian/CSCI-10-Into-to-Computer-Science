#include <iostream>
#include <cmath>
#include <math.h>
using namespace std;
//gives (x,y) coordinates for projectile x from 0 to 9 using for
int main(){
int x;
double y;
double y0;
double g;
double v;
double Theta;

cout<<"Enter initial launch angle in radians: "<<endl;
cin>>Theta;
cout<<"Enter initial launch velocity in m/s: "<<endl;
cin>>v;
cout<<"Enter initial height of projectile in m: "<<endl;
cin>>y0;

g=9.81;

for(x=0;x<10;x++){
  y=y0+(x*tan(Theta))-((g*(pow(x,2)))/(2*pow(v*cos(Theta),2)));
  cout<<"("<<x<<","<<y<<")"<<endl;
}
return 0;
}
