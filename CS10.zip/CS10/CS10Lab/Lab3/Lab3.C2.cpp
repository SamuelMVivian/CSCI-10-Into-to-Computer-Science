#include <iostream>
using namespace std;

int main(){

int count = 2;
int prime;

cout<<"Enter a number:"<<endl;
cin>>prime;

  for(count=2; count<prime; count++){
    if (prime % count == 0){
    cout<<"not prime"<<endl;
    break;
  }
  }
  if(count==prime){
    cout<<"prime"<<endl;
  }
 return 0;
}
